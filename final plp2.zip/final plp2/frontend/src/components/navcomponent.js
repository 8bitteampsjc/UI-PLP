import React from "react";
import { Link } from "react-router-dom";

export const NavComponent = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark    ">
      <div className ="container-fluid">
         <div className="navbar-header">
          <Link className="navbar-brand glyphicon glyphicon-home" to="/">
           Home
          </Link>
        </div> 

        <div  className="navbar navbar-collapse"
          id="bs-example-navbar-collapse-1">
          <ul className="nav navbar-nav ">
            <li>
              <Link to="/about" className="glyphicon glyphicon-aboutus">AboutUs</Link>
              <span className="sr-only" />
            </li>
          </ul>

          <ul className="nav navbar-nav navbar-right">
            <li>
              <Link class="glyphicon glyphicon-log-in" to="/login">&nbsp;Login</Link>
            </li>
            <li>
              <Link class="glyphicon glyphicon-user" to="/register">&nbsp;Register</Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default NavComponent;
