import React from 'react';
export class Home extends Component {
  
    render() {
  
  return (
    <ConnectionsStyles className='connections'>
      <div className='connectionsNumber'>
        <h1>534</h1>
        <h2>Your connections</h2>
        <h3>See all</h3>
      </div>
      <div className='addContact'>
        <h2>Add person contact</h2>
        <form><input type='text' /></form>
        <button>Continue</button>
        <h3>More options</h3>
      </div>
      <div className='learnMore'>
        <p>We'll import your address book to suggest connections. Learn more</p>
      </div>
    </ConnectionsStyles>
  )
}
}

export default Connections;