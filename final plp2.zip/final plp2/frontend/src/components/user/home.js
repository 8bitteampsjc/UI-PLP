import React, { Component } from 'react'
import Register from './register';
import NavComponent from '../navcomponent';

export class Home extends Component {
  render() {
    return (
      <div>
           <NavComponent/>
          

           <h1>YOU JOIN</h1>


          <Register/>
          
      </div>
    )
  }
}

export default Home
