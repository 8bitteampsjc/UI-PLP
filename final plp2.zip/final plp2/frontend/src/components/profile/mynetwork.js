class mynetwork extends Component {
    state = { dummyData };

    render() {
        return (
          <div className="App">
    
            <BodyContainerStyle>
              <Connections />
              <PeopleContainerStyle>
                {this.state.dummyData.map((person, i) => {
                  return (
                    <People 
                      key={i} 
                      person={person}
                    />)
                })}
              </PeopleContainerStyle>
              <Promoted />
            </BodyContainerStyle>
          </div>
        );
      }
}

export default mynetwork;