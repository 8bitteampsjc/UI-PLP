import React from 'react';
import {
    Card, CardImg, CardText, CardBody, CardHeader,CardFooter,
    CardTitle, CardSubtitle, Button
} from 'reactstrap';
import UserNavComponent from '../usernavcomponent'

const UserHome = (props) => {
    return (
      <div>
              <UserNavComponent/>
       <div
       className="container">

       <div
         className="row">

         <div
           className="col-lg-3">

         <Card>

            <CardHeader>

               <a
                 href="#">

                 <img

                   className="ronded"

                   src={require('../../images/1.jpg')}
                   align="center"

                   width="200px"

                   height="200px"

                 />

                 <h3
                   align="center">Bill Gates</h3>

               </a>

               </CardHeader>

               <CardBody>

               <font
                 size="2"
                 className="h9 text-muted"

               >Connections&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;<a
                   href="#"

                 >50</a

                 > </font

               ><br />

               <font
                 size="2"
                 className="h9 text-muted"

               >Following&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;<a

                   href="#"

                 >50</a

                 >

               </font>

               </CardBody>
          <CardFooter>
             
               <font
                 size="2"
                 className="h9 text-muted"

               >Persons viewed your profile</font

               >

               &nbsp;<a
                 href="#">50</a>

         </CardFooter>

        </Card>

           <br />

           <Card>

           <CardHeader>

               <font
                 size="2"
                 className="h9 text-muted">Recent</font><br
               />

               <font
                 size="2.8"
                 className="h9">#
<a
                   href="#">Capgemini</a></font

               ><br />

               <font
                 size="2.8"
                 className="h9">#
<a
                   href="#">Accenture</a></font

               ><br />

               <font
                 size="2.8"
                 className="h9">#
<a
                   href="#">Wipro</a></font

               ><br />

               <font
                 size="2.8"
                 className="h9">#
<a
                   href="#">Tech Mahindra</a></font

               ><br /><br />

               <a
                 href="#">Groups</a><br
               />

               <font
                 size="2.8"
                 className="h9">#
<a
                   href="#">IT</a></font

               ><br />

               <font
                 size="2.8"
                 className="h9">#
<a
                   href="#">BPO</a></font

               ><br />

               <font
                 size="2.8"
                 className="h9">#
<a
                   href="#">Services</a></font

               ><br />

               <font
                 size="2.8"
                 className="h9">#
<a
                   href="#">Electronics</a></font

               ><br />

            </CardHeader>

           </Card>

         </div>

         <div
           className="col-lg-6">

           <Card>

           <CardHeader>

               <form
                 className="form-group">

                 <textarea

                   type="text"

                   className="form-control"

                   placeholder="Hi Sai Post Here....."

                 ></textarea>

               </form>

             </CardHeader>
             <CardBody>

               <button
                 className="btn btn-outline-dark">Post</button>

           </CardBody>

           </Card>

           <br />

          <CardBody>

             <div
               className="text-muted h7 mb-2">

               <i
                 className="fa fa-clock-o"></i>10
                min ago
               
</div>

             <a
               className="card-link"
               href="#">

              
               <CardTitle>

               <h4> your Post Title</h4>
                 </CardTitle>


             </a>


             <CardText>
             <p>

               your post is here...your post is here...your post is here...your post
               
               is here... your post is here...your post is here...your post is
               
               here...your post is here...
               
</p> 
</CardText>



            <CardFooter>

               <a
                 href="#"
                 className="card-link"><i
                 className="fa fa-gittip"></i>
                 Like</a>
                 &nbsp;&nbsp;

               <a
                 href="#"
                 className="card-link"

               ><i
               className="fa fa-comment"></i>
                 Comment</a

               >&nbsp;&nbsp;

               <a
                 href="#"
                 className="card-link"

               ><i
               className="fa fa-mail-forward"></i>
                 Share</a

               >

             </CardFooter>

        </CardBody>

           <CardBody>

             <div
               className="text-muted h7 mb-2">

               <i  className="fa fa-clock-o"></i>10
                min ago
               
</div>

             <a
               className="card-link"
               href="#">
               <CardTitle>
               <h4> your Post Title
                 
</h4>
</CardTitle>
             </a>

              <CardText>
             <p>

               your post is here...your post is here...your post is here...your post
               
               is here... your post is here...your post is here...your post is
               
               here...your post is here...
               
</p>
</CardText>


             <CardFooter>

               <a
                 href="#"
                 className="card-link"><i
                 className="fa fa-gittip"></i>
                 Like</a>&nbsp;&nbsp;

               <a
                 href="#"
                 className="card-link"

               ><i
               className="fa fa-comment"></i>
                 Comment</a

               >&nbsp;&nbsp;

               <a
                 href="#"
                 className="card-link"

               ><i
               className="fa fa-mail-forward"></i>
                 Share</a

               >

             </CardFooter>

           </CardBody>

           <CardBody>

             <div
               className="text-muted h7 mb-2">

               <i
                 className="fa fa-clock-o"></i>10
                min ago
               
</div>

             <a
               className="card-link"
               href="#">
            <CardTitle>
               <h4>
your Post Title            
</h4>
</CardTitle>

             </a>

           <CardText>

             <p>

               your post is here...your post is here...your post is here...your post
               
               is here... your post is here...your post is here...your post is
               
               here...your post is here...
               
</p>
</CardText>


             <CardFooter>

               <a
                 href="#"
                 className="card-link"><i
                 className="fa fa-gittip"></i>
                 Like</a>&nbsp;&nbsp;

               <a
                 href="#"
                 className="card-link"

               ><i
               className="fa fa-comment"></i>
                 Comment</a

               >&nbsp;&nbsp;

               <a
                 href="#"
                 className="card-link"

               ><i
               className="fa fa-mail-forward"></i>
                 Share</a

               >

             </CardFooter>

           </CardBody>

         </div>

         <div
           className="col-lg-2"></div>

       </div>

       <br />

     </div>
     </div>

    );
};

export default UserHome;