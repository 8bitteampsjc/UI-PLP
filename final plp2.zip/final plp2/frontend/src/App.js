import React, { Component } from 'react';
import './App.css';
import {BrowserRouter as Router, Switch, Route } from 'react-router-dom'
import Login from './components/user/login';
import About from './components/user/about';
import Register from './components/user/register';
import Home from './components/user/home';
import UserHome from './components/profile/userhome';
import Example from './components/card';
import useHome from './components/profile/useHome';


class App extends Component {
  render() {
    return (
      <Router>
      <div className="container" align="textcenter">

        <Switch>   
        <Route exact path='/' component={Home}/>
         <Route exact path='/login' component={Login}/>
         <Route exact path='/about' component={About}/>
         <Route exact path='/register' component={Register}/>
         <Route exact path='/userhome' component={UserHome}/>
         <Route exact path='/Example' component={Example}/>
         <Route exact path='/usehome' component={useHome}/>
         
  
        </Switch>
      </div>
      </Router>
    )
}
}

export default App;
