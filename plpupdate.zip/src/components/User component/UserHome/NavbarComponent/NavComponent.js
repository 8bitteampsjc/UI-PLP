import React from "react";


import { Link } from "react-router-dom";
import images from "../NavbarComponent/images/down.png";

export const NavComponent = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-inverse bg-inverse ">
    <div className="row">
        
        <div className="col-lg-4">
        <br/>
        {/* <div className="search-container">
          
          <input type="text" placeholder="Search Here"/>
          &nbsp;&nbsp;
          <button className="btn btn-primary">Search</button>
           </div> */}
           <form class="navbar-form navbar-left" action="">
              <div class="form-group">
              <input type="text" class="form-control" placeholder="Search"/>
               </div>&nbsp;
            <button type="submit" class="btn btn-default">Submit</button>
            </form>
          
           </div>
           <div className="col-lg-5">
           
    
      <div className="container-fluid">
        <div className="navbar-header">
          &nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        
        <div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul className="nav navbar-nav navbar-right">
            <li>
              <Link className="fas fa-home fa-3x" to="/userhome">&nbsp;&nbsp;</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </li>
            <li>
              <Link  className="fas fa-briefcase fa-3x" to="/managejob">&nbsp;&nbsp;</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <span className="sr-only" />
            </li>
            <li>
              <Link className="fas fa-users fa-3x" to="/network" >&nbsp;&nbsp;</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </li>
            <li>
              <Link className="fas fa-user fa-3x" to="/userprofile" >&nbsp;&nbsp;</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </li>
            <li>
              <Link className="fa fa-bell fa-3x" to="/notifications">
       
                <span className ="badge badge-info">2</span>&nbsp;&nbsp;

              </Link>
              &nbsp;&nbsp;&nbsp;&nbsp;
            </li>
          </ul>
         </div>
         </div>
    </div>   
 
    </div>
    <div className="col-lg-3">
        <img src={images} width="100px" height="75px " />
        </div>
    </div>
    </nav>
    
  );
};

export default NavComponent;
