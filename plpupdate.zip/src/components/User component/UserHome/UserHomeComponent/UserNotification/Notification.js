import React from 'react'
import Promoted1 from './Promoted1'
import Promoted2 from './Promoted2';
import NotificationData from './NotoficationData';
import notiDummyData from './Notification-Dummy-Data';
import NavComponent from '../../NavbarComponent/NavComponent';

class Notifications extends React.Component {
    state = { notiDummyData };
    render() {
        return (
            
            <div>
            <NavComponent/>
              
                <div className="row">
                    <div className="col-lg-3">
                        <Promoted1 />
                    </div>
                    <div className="col-lg-6">
                        {this.state.notiDummyData.map((noti, i) => {
                            return (
                                <NotificationData key={i} noti={noti}  />)
                        })}
                    </div>
                    <div className="col-lg-3">
                        <Promoted2 />
                    </div>
                </div>
            </div>
        )
    }
}

export default Notifications