import React from 'react';
import { Link } from "react-router-dom";
import Card from 'react-bootstrap/Card';
import {ListGroup}  from 'react-bootstrap';
import NavComponent from '../NavbarComponent/NavComponent';
import { CardImg, CardText, CardBody, CardHeader,CardFooter,CardTitle, CardSubtitle, Button } from 'reactstrap';

export class Cards extends React.Component {

  render() {
    return (
      <div>
              <NavComponent/>
       <div
       className="container">

       <div
         className="row">

         <div
           className="col-lg-3">

         <Card>

            <CardHeader>

               <a
                 href="#">

                 <img

                   className="img-fluid img-circle" 

                   src={require('./1.jpg')}
                   align="center"

                   width="200px"

                   height="200px"

                 />

                 <h3
                   align="center">Bill Gates</h3>

               </a>

               </CardHeader>

               <CardBody>

               <font
                 size="2"
                 className="h9 text-muted"

               >Connections&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;<a
                   href="#"

                 >50</a

                 > </font

               ><br />

               <font
                 size="2"
                 className="h9 text-muted"

               >Following&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;<a

                   href="#"

                 >50</a

                 >

               </font>

               </CardBody>
          <CardFooter>
             
               <font
                 size="2"
                 className="h9 text-muted"

               >Persons viewed your profile</font

               >

               &nbsp;<a
                 href="#">50</a>

         </CardFooter>

        </Card>

           <br />

           <Card>

           <CardHeader>

               <font
                 size="2"
                 className="h9 text-muted">Recent</font><br
               />

               <font
                 size="2.8"
                 className="h9">#
<a
                   href="#">Capgemini</a></font

               ><br />

               <font
                 size="2.8"
                 className="h9">#
<a
                   href="#">Accenture</a></font

               ><br />

               <font
                 size="2.8"
                 className="h9">#
<a
                   href="#">Wipro</a></font

               ><br />

               <font
                 size="2.8"
                 className="h9">#
<a
                   href="#">Tech Mahindra</a></font

               ><br /><br />

               <a
                 href="#">Groups</a><br
               />

               <font
                 size="2.8"
                 className="h9">#
<a
                   href="#">IT</a></font

               ><br />

               <font
                 size="2.8"
                 className="h9">#
<a
                   href="#">BPO</a></font

               ><br />

               <font
                 size="2.8"
                 className="h9">#
<a
                   href="#">Services</a></font

               ><br />

               <font
                 size="2.8"
                 className="h9">#
<a
                   href="#">Electronics</a></font

               ><br />

            </CardHeader>

           </Card>

         </div>

         <div
           className="col-lg-6">

           <Card>

           <CardHeader>

               <form
                 className="form-group">

                 <textarea

                   type="text"

                   className="form-control"

                   placeholder="Post Here....."

                 ></textarea>

               </form>

             </CardHeader>
             <CardBody>

               <button
                 className="btn btn-outline-dark">Post</button>

           </CardBody>

           </Card>

           <br />

          <CardBody>

             <div
               className="text-muted h7 mb-2">

               <i
                 className="fa fa-clock-o"></i>10
                min ago
               
</div>

             <a
               className="card-link"
               href="#">

              
               <CardTitle>

               <h4> your Post Title</h4>
                 </CardTitle>


             </a>


             <CardText>
             <p>

               your post is here...your post is here...your post is here...your post
               
               is here... your post is here...your post is here...your post is
               
               here...your post is here...
               
</p> 
</CardText>



            <CardFooter>

               <a
                 href="#"
                 className="card-link"><i
                 className="fa fa-gittip"></i>
                 Like</a>
                 &nbsp;&nbsp;

               <a
                 href="#"
                 className="card-link"

               ><i
               className="fa fa-comment"></i>
                 Comment</a

               >&nbsp;&nbsp;

               <a
                 href="#"
                 className="card-link"

               ><i
               className="fa fa-mail-forward"></i>
                 Share</a

               >

             </CardFooter>

        </CardBody>

           <CardBody>

             <div
               className="text-muted h7 mb-2">

               <i  className="fa fa-clock-o"></i>10
                min ago
               
</div>

             <a
               className="card-link"
               href="#">
               <CardTitle>
               <h4> your Post Title
                 
</h4>
</CardTitle>
             </a>

              <CardText>
             <p>

               your post is here...your post is here...your post is here...your post
               
               is here... your post is here...your post is here...your post is
               
               here...your post is here...
               
</p>
</CardText>


             <CardFooter>

               <a
                 href="#"
                 className="card-link"><i
                 className="fa fa-gittip"></i>
                 Like</a>&nbsp;&nbsp;

               <a
                 href="#"
                 className="card-link"

               ><i
               className="fa fa-comment"></i>
                 Comment</a

               >&nbsp;&nbsp;

               <a
                 href="#"
                 className="card-link"

               ><i
               className="fa fa-mail-forward"></i>
                 Share</a

               >

             </CardFooter>

           </CardBody>

           <CardBody>

             <div
               className="text-muted h7 mb-2">

               <i
                 className="fa fa-clock-o"></i>10
                min ago
               
</div>

             <a
               className="card-link"
               href="#">
            <CardTitle>
               <h4>
your Post Title            
</h4>
</CardTitle>

             </a>

           <CardText>

             <p>

               your post is here...your post is here...your post is here...your post
               
               is here... your post is here...your post is here...your post is
               
               here...your post is here...
               
</p>
</CardText>


             <CardFooter>

               <a
                 href="#"
                 className="card-link"><i
                 className="fa fa-gittip"></i>
                 Like</a>&nbsp;&nbsp;

               <a
                 href="#"
                 className="card-link"

               ><i
               className="fa fa-comment"></i>
                 Comment</a

               >&nbsp;&nbsp;

               <a
                 href="#"
                 className="card-link"

               ><i
               className="fa fa-mail-forward"></i>
                 Share</a

               >

             </CardFooter>

           </CardBody>

         </div>

         <div
           className="col-lg-2"></div>
<div className="col-lg-3">
      <div className="container">
      <Card style={{border:'2px solid black', width: '25rem'  }}>
    
  
   
      <Card.Body>
      <div className="text-center bg-danger">
      <Card.Title className="text-center"><b>&nbsp; &nbsp; &nbsp; &nbsp; Trending news &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;   <span class="glyphicon glyphicon-info-sign"></span></b></Card.Title>
       </div>
        <ListGroup variant="flush">
  <ListGroup.Item><li><Link to="/connections1" >Elections are going on</Link></li><h6>15hrs ago &nbsp; &nbsp;	◘&nbsp;367 readers</h6></ListGroup.Item>
  <ListGroup.Item><li><Link to="/connections2" >
AB de Villiers Comes Up With Hilarious Nickname For Virat Kohli After Eden Gardens Masterclass</Link></li><h6>2days ago &nbsp; &nbsp;	◘&nbsp;367,25 readers</h6></ListGroup.Item>
  <ListGroup.Item><li><Link to="/connections3" >Google Gives Pixel 3 Owner 10 Replacement Phones Instead of Refund: Report</Link></li><h6>3days ago &nbsp; &nbsp;	◘&nbsp;2 readers</h6></ListGroup.Item>
  <ListGroup.Item><li><Link to="/connections4" > OnePlus 7, OnePlus 7 Pro Launch Date to Be Announced on Tuesday, CEO Pete Lau Says</Link></li><h6>2m ago &nbsp; &nbsp;	◘&nbsp;500k</h6></ListGroup.Item>
  <ListGroup.Item><li><Link to="/connections5" > Hardik Panyda, KL Rahul Fined Rs. 20 Lakh Each By BCCI Ombudsman For TV Show Comments</Link></li><h6>3days ago &nbsp; &nbsp;	◘&nbsp;200readers </h6></ListGroup.Item>





  <ListGroup.Item><li><Link to="/connections6" > 10 Takeaways From 2 Rounds Of Voting In Bihar: NDA Is Squad Goals
</Link></li><h6>2days ago &nbsp; &nbsp;	◘&nbsp;367,25 readers</h6></ListGroup.Item>

 





</ListGroup>

        
      </Card.Body>
    </Card>
    </div>
    </div>
       </div>

       <br />

     </div>

     
     </div>
     
        
        
   
    )
}
}
export default Cards;