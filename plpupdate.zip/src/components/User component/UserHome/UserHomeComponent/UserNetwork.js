import React from 'react';
import NavComponent from '../NavbarComponent/NavComponent';

class UserNetwork extends React.Component{
    render(){
        return(
            <div>
                <NavComponent/>
            <h1>User Network</h1>
            </div>
        )
    }
}
export default UserNetwork;