import React, { Component } from "react";
import { Row, Col, FormGroup, ControlLabel, FormControl } from "react-bootstrap";
import avatar from "./images/profileImage.png";
import UserCard from './UserCard/UserCard'
import NavComponent from "../../NavbarComponent/NavComponent";
import Card from 'react-bootstrap/Card';
import { CardImg, CardText, CardBody, CardHeader,CardFooter,CardTitle, CardSubtitle, Button } from 'reactstrap';


class UserProfile extends Component {


  render() {
    return (
      <div className="content">
        <NavComponent />

<div className="row">
<div className="col-lg-4">
        <UserCard
          avatar={avatar}
          name="Mike Andrew"
          userName="michael24"
          description={
            <span>
              "Lamborghini Mercy
                    <br />
              Your chick she so thirsty
                    <br />
              I'm in that two seat Lambo"
                  </span>
          }

          
        />
        </div>
        <div className="col-lg-4">
        <Card>
          <CardHeader>
            <h3>About</h3>
          </CardHeader>
          <CardBody>
            <font
              size="2"
              className="h9 text-muted"
            >Lives in New Delhi</font
            ><br/>
            <font
              size="2"
              className="h9 text-muted"
            >Lives in New Delhi</font
            ><br />
          </CardBody>
          <CardFooter>
          <a href={'/editprofile'} className="btn btn-warning ">Edit Profile</a>
          </CardFooter>
        </Card>
        <Card>
          <br/>
          <hr/>
          <CardHeader>
            <h3>Experience</h3>
          </CardHeader>
          <CardBody>
            <font
              size="2"
              className="h9 text-muted"
            >Worked at CSPL Company,Delhi</font
            ><br />
            <font
              size="2"
              className="h9 text-muted"
            >Currently working at Capgemini</font
            >
          </CardBody>
          <CardFooter>
          <a href={'/addexperience'} className="btn btn-primary">Add Experience</a>
          </CardFooter>
        </Card>
        </div>
        <div className="col-lg-4">
        <Card>
          <CardHeader>
            <h3>Education</h3>
          </CardHeader>
          <CardBody>
            <font
              size="2"
              className="h9 text-muted"
            >Studied at SVMS School</font
            ><br />
            <font
              size="2"
              className="h9 text-muted"
            >Engneering from IPU Delhi</font
            >
          </CardBody>
          <CardFooter>
          <a href={'/editprofile'} className="btn btn-warning ">Add Education</a>
          </CardFooter>
        </Card>
        <br/>
          <hr/>
        <Card>
          <CardHeader>
            <h3>Skills</h3>
          </CardHeader>
          <CardBody>
            <font
              size="2"
              className="h9 text-muted"
            >Languages Known C,JavaScript,Etc...</font
            ><br />
            <font
              size="2"
              className="h9 text-muted"
            >Engneering from IPU Delhi</font
            >
          </CardBody>
          <CardFooter>
          <a href={'/addskill'} className="btn btn-success ">Add Skill</a>
          </CardFooter>
        </Card>
        </div>
        <div>
          

          

          
        </div>

          </div>
       <hr/>
            <div align="center">
              <button>
                <i className="fab fa-facebook-square fa-2x" />
              </button>
              <button>
                <i className="fab fa-twitter fa-2x" />
              </button>
              <button>
                <i className="fab fa-google-plus-square fa-2x" />
              </button>
            </div>
          

      </div>
    );
  }
}

export default UserProfile;